#include<iostream.h>
#include<conio.h>
#include<string.h>
using namespace std;
class Person 
{
public:
	string firstname;
	string middlename;
	string lastname;

void personName(string fname,string mname ,string lname)
	{

	
	firstname=fname;
	middlename=mname;
	lastname=lname;
	}

void personName(string fname,string mname )	
	{
	firstname=fname;
	middlename=mname;
	}

void personName(string fname)
	{
	firstname=fname;
	}
	//string getFirstName()
	//{
	//return firstname;
	//}
	
};

main()
{
Person p1;
	p1.personName("Sumit","Kumar","Ray");
	//cout<<p1.getFirstName()<<endl;
	cout<<p1.firstname<<" "<<p1.middlename<<" "<<p1.lastname<<endl;

Person p2;
	p2.personName("Amit","Kumar");
	cout<<p2.firstname<<" "<<p2.middlename<<endl;

Person p3;
	p3.personName("Raj");
	cout<<p3.firstname<<endl;	
}