#include<iostream.h>

class Base
{
	public:
	virtual void attak()=0;
};
class Hell:public Base
{
	void attak()
	{
		cout<<"Got Damm "<<endl;
	}
};
main()
{
	Hell h;
	Base *b=&h;
	b->attak();
}