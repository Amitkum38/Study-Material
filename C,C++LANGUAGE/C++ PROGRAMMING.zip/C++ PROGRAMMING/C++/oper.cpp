#include<iostream.h>
#include<conio.h>
#include<string.h>

using namespace std;

class Person
{
public:
	int age;
Person operator+(Person p)
Person newPerson;
int age=P.age+this->age;
newPerson.age=age;
return newPerson;
}
};

main()
{
Person p1;
Person p2;
	cout<<"Enter age"<<endl;
	cin>>p1.age;
	cin>>p2.age;
	
p1.age;
p2.age;

Person p3=p1+p2;
cout<<p3.age<<endl;
}	