#include<iostream.h>
#include<conio.h>
#include<string.h>
#include<stdio.h>
using namespace std;
class Emp
{
private:
	int id;
public:
		Emp(int i)
		{	
		id=i;
		}
		int getId()
		{
		return id;
		}
};

main()
{
	Emp e(7);
	cout<<e.getId()<<endl;	
}

