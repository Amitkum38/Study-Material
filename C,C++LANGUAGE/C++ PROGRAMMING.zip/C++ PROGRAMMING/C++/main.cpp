#include<string.h>
#include<iostream.h>
#include<stdio.h>
#include<conio.h>
int main()
{
string s;
cout<<"enter a string"<<endl;
cin>>s;
cout<<"you entered "<<s<<endl; 


return 0;
}