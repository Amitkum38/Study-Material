#include<iostream.h>
#include<fstream>
#include<string>
using namespace std;
void main() 
{

string book;
float price;

ofstream  myfile;
myfile.open("A.txt");

cout<<"Enter book and its price"<<endl;
cin>>book>>price;

myfile<<book<<price<<endl;

}


