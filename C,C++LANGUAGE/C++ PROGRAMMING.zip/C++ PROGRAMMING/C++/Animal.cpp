#include<iostream>

using namespace std;

class Animal
{

public:	
	Animal()
		{
			cout<<"i am in Animal constructor"<<endl;
		}
	~Animal()
		{
			cout<<"i am in Animal destructor"<<endl;
		}
		
};

int main()
{
Animal al;
Animal a2;
return 0;
}