#include<iostream>
#include<stdio.h>
#include<conio.h>

using namespace std;
void main()
{
cout<<"hello"<<endl;
}

