#include<iostream.h>
using namespace std;

class Animal
{
private:
	int age;
public:
	Animal(int age)
	{
	this->age=age;
	}
	int getAge()
	{
	return this->age;
	}
};

main()
{
Animal a1(20);
	cout<<a1.getAge()<<endl;
	
Animal a2(30);
	cout<<a2.getAge()<<endl;
}	