#include<iostream.h>
#include<fstream>
using namespace std;
void main()
{
ifstream myfile;

myfile.open("A.txt");

 string name;
 int id;
 float salary;
 
while(myfile>>name>>id>>salary)
	{
	cout<<name<<"\n"<<id<<"\n"<<salary<<endl;
	}
	
myfile.close();
}

