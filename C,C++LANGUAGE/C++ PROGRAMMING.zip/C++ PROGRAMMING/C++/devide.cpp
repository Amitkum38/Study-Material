#include<iostream.h>
#include<conio.h>

using namespace std;

class Calculator
{
public:
int devide(int a,int b)
{
try
	{
	if(b==0)
		{
		throw 12;
		}
	else
	{
	return (a/b);
	}
	
	}
	

catch(int n)
{
cout<<"you can't devide by 0 error no is "<<n<<endl;
}
}
};
	
main()
{
Calculator d;
int x,y;

cout<<"Enter x and y"<<endl;
cin>>x>>y;


int z=d.devide(x,y);
cout<<"x/y="<<z<<endl;
}	