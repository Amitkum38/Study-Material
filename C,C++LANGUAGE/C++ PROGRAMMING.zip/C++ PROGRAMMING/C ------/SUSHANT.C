#include<stdio.h>
#include<conio.h>

int reverse(int);
int factorial(int);
void palindrom(int);
void display()
{


printf("enetr the num");
int num;
scanf("%d",&num);
printf("1. press 1 for reverse \n");
printf("2. press 2 for palindrom\n");
printf("3. press 3 for factorial\n");
int choice;
scanf("%d",& choice);
switch(choice)
{
case 1:

printf("reverse is=%d",reverse(num));
break;
case 2:
palindrom(num);
break;
case 3:
if(num<1 || num>6)
{
printf("enter num between 1 and 6");
scanf("%d",&choice);
}
else
{
int fact=factorial(num);
printf("factorial=%d",fact);
}
break;
default:
printf("wrong choice");
}


}

void main()
{
clrscr();
void display();
display();
getch();
}
int reverse(int num)
{
int  rem=0;
while(num>0)
{
rem=rem*10+num%10;
num=num/10;

}
return rem;
}
void palindrom(int num)
{
int rev=reverse(num);
if(rev==num)
{
printf("yes it is a palindrom");
}
else
{
printf("its not a palindrom");
}
}
int factorial(int num)
{
int res=1;
while(num>0)
{
res=res*num;
num--;
}
return res;

}