<?php

$a=3;
echo ($a%2==0) ? 
" number is even " :
" number is add  " ;

?>