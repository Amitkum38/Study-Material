<?php
$ram="Go";
$no="1";

if($ram=="god"){
echo "ram Is God";
}
else{
echo "ram is not god";

}




?>