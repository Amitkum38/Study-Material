<?php
$a = 5;

if(@$a%2==0)
{
echo "number is even";
}
else
{
echo  "number is odd";
}
?>