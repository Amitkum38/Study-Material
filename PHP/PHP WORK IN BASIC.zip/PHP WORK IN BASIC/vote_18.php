<?php

$age=17;
echo ($age>=18) ?
"User can  cast the vote" :
"User can not cast the vote"; 

?>