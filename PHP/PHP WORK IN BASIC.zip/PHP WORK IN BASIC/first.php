<?php
$value1="Ram Is Good Boy";
$value2="Ram Is Great Boy";
echo $value1."<br>";
echo $value2;

?>