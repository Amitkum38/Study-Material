<?php
echo 'what is php'.'<br>'.'php is p';
$name = 'amitkumar';
$age = 20;
$Roll_no = 1;
?>

<p> your name is 
<?php 
echo $name.'</br>';
?>

your age is 
<?php
echo $age.'</br>';
?>

 your Roll_no is
<?php 
echo $Roll_no.'</br>';
  ?>
  
<?php
echo $age.'</br>';
unset($age);
echo @$age;
      $age2 = @age;
 	  
	  
?>
<?php
define ("constantname","constantvalue");
define ("thinkncode","11045");
echo  thinkncode.'<br>';
?>

<?php
$number1 = 50;
$number2 = 20;
$sum = $number1 + $number2;
echo $sum.'</br>';
?>

<?php 
$ans =5+5*5;
echo $ans.'</br>';
?>

<?php 
$result1 =1+1*2/1;
echo $result1.'</br>';
?>

<?php 
$result2 =(1+4)*2+1;
echo $result2.'</br>';
?>
 
 <?php 
$result3 = (1+2)*4+2;
$result4= 3*4+1;
$result5= 10+1;
$result6= 12-4;
$result7= 10/8;
echo $result3.'</br>'.$result4.'</br>'.$result5.'</br>'.$result6.'</br>';
?>

<?php 
$price = 25;
$f_price = sprintf("%01.2f" , $price);
echo $f_price .'<br/>';
?>

 <?php 
$price = 500;
$f_price = number_format($price,2);
echo $f_price .'<br/>';
?>

 <?php 
$string1 ='think-n-code';
$string2 ='anibabbar';
$string3 = 'compny';
echo $string1.'</br>'.$string2.'</br>'.$string3 .'</br>';
?>

 <?php 
$string = 'It is sunil\'s  house';
echo $string. '<br>';
?>
 
 <?php 
$age = 20;
$ageamit = "age";
$agesachin = "$age"; 
echo $ageamit.$agesachin.'</br>';
?>

<?php
$string4 = "string in\ndouble quotes".'</br>';
$string5 = 'string in\nsingle quotes'.'</br>';
echo $string4;
echo $string5; 
?>

<?php
$string6 = "string in\tdouble quotes".'</br>';
$string7= 'string in\tsingle quotes'.'</br>';
echo $string6;
echo $string7; 
?>

<?php
$number =10;
$string9 = "there are '$number people in line'".'</br>';
$string10 = "there are '$number people in waiting'".'</br>';
echo $string9;
echo $string10;
?>
<?php
$string11 = 'hello'.'</br>';
$string12 = 'amitkumar'.'</br>';
echo $string11;
echo $string12;
?>
<?php
$string13 = "DEPPAK";
$string13 = "SUJEET";
echo $string13;
?>
