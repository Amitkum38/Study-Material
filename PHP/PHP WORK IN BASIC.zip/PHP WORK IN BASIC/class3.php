<?php
//integer 
$large_number = 2147483647;
var_dump($large_number);
?>

<br>
<?php
//float
$large_number1 = 2147483648;
var_dump($large_number1);
				
$friend= array('a'=>'Amit',
			   'd'=> 'deepak',
			   's'=>'shyam'); 
print_r(@$array);
print_r($friend);
?>