<?php
$time = date("a");
$har =  date("h");
  if($time == 'am'){
echo "Good Morning";
  }
    if($time == 'pm'){
echo "Good Noon";
  }

 settype($har,"int");
 if($har>=4&&$time=="pm"&&$har<8){
 
 echo "GOOD EVENING";
 }


?>   