<?php
 echo "name of Month = ". date(" M"). "<br>";
 echo "name of Month = ". date("d m y"). "<br>";

?>