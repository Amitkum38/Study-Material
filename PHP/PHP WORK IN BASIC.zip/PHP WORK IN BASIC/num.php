<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>NUM IN WORDS</title>
</head>

<body>
<?php 
	@$num=$_POST['num'];
	//echo $num."<br>";
	$a=$num/10;
	settype($a,"int");
	//echo "a=".$a."<br>";
	$y=$num%10;
	//echo "y=".$y."<br>";

?>
<form action="num.php" method="post" enctype="multipart/form-data">
Enter a number :-  <input type="text" name="num" value="<?php echo $num; ?>"  /><input type="submit" name="sub" value="Submit" /><br>
<br>
<hr>
 Result :-
<?php

if($num<20&&$num>=10)
{
	if($num==10)
	printf("Ten");
	else if($num==11)
	printf("Eleven");
	else if($num==12)
	printf("Twelve");
	else if($num==13)
	printf("Thirteen");
	else if($num==14)
	printf("Fourteen");
	else if($num==15)
	printf("Fifteen");
	else if($num==16)
	printf("Sixteen");
	else if($num==17)
	printf("Seventeen");
	else if($num==18)
	printf("Eighteen");
	else if($num==19)
	printf("Nineteen");
}
else
{
	switch ($a)
	{
	case 2:
	 printf("twenty ");
	 break;
	case 3:
	  printf("thirty ");
	  break;
	case 4:
	  printf("fourty ");
	  break;
	case 5:
	  printf("fifty ");
	  break;
	case 6:
	  printf("sixty ");
	  break;
       case 7:
	 printf("seventy ");
	 break;
       case 8:
	 printf("eighty ");
	 break;
       case 9:
	 printf("ninty ");
	 break;
       }
       switch ($y)
       {
	case 0:
	 break;
	case 1:
	 printf("one");
	 break;
	case 2:
	 printf("two");
	 break;
	case 3:
	 printf("three");
	 break;
	case 4:
	 printf("four");
	 break;
	case 5:
	 printf("five");
	 break;
	case 6:
	 printf("six");
	 break;
	case 7:
	 printf("seven");
	 break;
	case 8:
	 printf("eight");
	 break;
	case 9:
	 printf("nine");
	 break;
	}
}
?>
</form>
</body>
</html>