<?php
$num = 10;
$name = "Delhi";
echo $num."<br>" ,$name."<br>";

$year = 2008;
echo $curyear = $year."<br>";

$number = "";
$number = NULL;
unset($number);

// @ it will hide the notice massage

$num0= 10;
$name = "Thinkncode";
echo @$num0."<br>", @$name."<br>";

$number1 = 15;
$number2 = 15.5;
$name = "Thinkncode";
var_dump($number1, $number2,$name);


define("delhi","puna");
define("Nokia100","Nokia101");
echo "PHP"."<br>","Nokia100"."<br>";

$number3 =4;
$number4 =2;
echo $number3+$number4."<br>";
echo $number3-$number4."<br>";
echo $number3*$number4."<br>";
echo $number3/$number4."<br>";
echo $number3%$number4."<br>";
echo "good morning 'good night'";

?>
