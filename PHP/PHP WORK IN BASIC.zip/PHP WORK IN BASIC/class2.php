<?php
/*naming a var.
	-------------
		-starts with $ and _ sign
		-use alpha. , _ , num.
		-name must starts letter & underscore only
		-var. are case sensitive e.g.  $name and $Name are different var
		- we do not use special symbol as , '' "" . # @ 
*/
$name = "Class1"."<br/>";
$Name = "Class2";
echo $name.$Name;
?>
<br>

<?php
/*Creating & assigning var.
	--------------------------
		- equalsign (=) is use to assign tve value to var
			eg. $num=20; $name= "Amit";

		- we can also assign like that eg-
			$year= 2008;
			$curyear=$year;
*/
$sachin= 2013;
echo $curAMIT=$sachin;
?>
<br>

<?php
/*Destorying var
	----------------
		-we can remove value of var by use of "" or NULL (data type)
			$num="";
			$num=NULL;
	
		-use unset() function for remove the vra eg.
			unset($num); //it will remove var.
*/			
$n="";
$n=NULL;
unset ($num);

?>
<br>

<?php
/*Dealing with Notice message or error
	------------------------------------
		- we use @ sign for remove the notice message before the var
			eg.  @$num;(it will hide the notice massage)
*/			
echo @Notice_message_error;
?>

<br>

<?php
/*
Display the var type,size and content
	----------------------------------------
		- var_dump(); function is used
		eg.   var_dump($num);
*/
$p1 = 3.16;
$p2 = "thinkncode";
var_dump($p1,$p2);			
?>
<br>

<?php
/*Php constant
	--------------
		value never be changed by program. and we declare const. by
		define("name of const","value") function
		eg.  	define("PHP","php");
			define("version","5.4");
*/
define ("thinkncode.com","thinkncode.in");
echo "thinkncode.com";			
?>

<br/>

<?php
/*
*/			
?>

<br>

<?php
/*
	*Working with Number, 
	------------------------
		All arithmatics operation +,_,*,/,%

		-number format for priceing
			number_format(var name, num of decimal placs)
*/
$p7 = 10;
$p8 = 10;
echo $p7-$p8."<br>";
echo $p7+$p8."<br>";
echo $p7*$p8."<br>";
echo $p7/$p8."<br>";
echo $p7%$p8."<br>";
?>

<?php
/* working with string
	------------------------
		-String is the series of char. like word, phrase sentences etc.
		-for create string in php we use single quote or double quote ('' or "")
		   both creats string
		 eg.  $name ='Gupta';
		      $Name ="Singh";
		
		---Difference in '' and "" 
		    ------------------
		  -when "" is used php perform var expansion 
			(evaluate the value of var and print the value)
		   when '' is used php treats as string constant
			 (Do not evaluate the value print as constant )

			 */
$name ='Gupta';
$Name ="Singh";
echo $name;
echo $Name;
?>