<?php
$number=1;
while($number<=100){
echo "<br>".$number++;
}

?>