<?php
$a=3;
$b=3;
if($a!=$b){
echo " than start for Sonytv";
}
else{
echo"than start for Star tv ";
}
?>