
<?php
switch ($date % 7) {
	case 0: 
		$day = "Tuesday";
		break;
	case 1: 
		$day = "Wednesday";
		break;
	case 2: 
		$day = "Thursday";
		break;
	case 3:
		$day = "Friday";
		break;
	case 4:
		$day = "Saturday";
		break;
	case 5:
		$day = "Sunday";
		break;
	case 6:
		$day = "Monday";
		break;
	default: 
		$day = "no such day";	
}
print "Today is $day\n";
?>