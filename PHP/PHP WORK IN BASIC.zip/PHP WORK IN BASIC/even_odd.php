<?php
$num = 13;
if($num&1) {
echo 'The number is odd.';
}
else {
echo 'The number is even.';
}
?>

