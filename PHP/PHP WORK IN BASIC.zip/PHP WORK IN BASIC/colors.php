<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>BackGround Color</title>
</head>
<?php 
		
		@$s=$_POST['bl'];
		@$s1=$_POST['gr'];
		@$s2=$_POST['red'];
		@$s3=$_POST['yl'];
		
?>
<body bgcolor="<?php if($s=="blue")echo $s;
				if($s1=="LightGreen")echo $s1;
				if($s2=="Red")echo $s2;
				if($s3=="Gold ")echo $s3; ?>"
  >
	<form action="colors.php" method="post" >
	<h1> Color Selector</h1>
	<hr>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Blue :</b>
        <input type="submit" name="bl" value="blue"
        	 style="font-size:15pt;color:white;background-color:blue;border:2px solid #336600;padding:3px"><br><br>
   
   		&nbsp;&nbsp;&nbsp;<b>Green :</b>
          <input type="submit" name="gr"  value="LightGreen"
           style="font-size:15pt;color:white;background-color:LightGreen;border:2px solid #336600;padding:3px"><br> <br>
           
	    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Red :</b>
         <input type="submit" name="red"  value="Red" 
         style="font-size:15pt;color:white;background-color:Red;border:2px solid #336600;padding:3px"><br><br>
         
    	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Yello :</b>
         <input type="submit" name="yl"  value="Gold "
          style="font-size:15pt;color:white;background-color:Gold ;border:2px solid #336600;padding:3px"><br><br>
          
</form>
</body>
</html>