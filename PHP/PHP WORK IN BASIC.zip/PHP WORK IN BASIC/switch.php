<?php
$dat=date("T");
switch ($dat)
{
  case 0:
    print("Today is Sunday");
   break;
  case 1:
    print("Today is Monday");
    break;
  case 2:
    print("Today is Tuesday");
    break;
  case 3:
    print("Today is Wednesday");
    break;
  case 4:
    print("Today is Thursday");
    break;
  case 5:
    print("Today is Friday");
    break;
    case 6:
    print("Today is Saturday");
    break;
  }
?>