import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

ReactDOM.render(<App primeMember={true} />, document.getElementById("root"));
// ReactDOM.render(<App primeMember={false} />, document.getElementById("root"));
