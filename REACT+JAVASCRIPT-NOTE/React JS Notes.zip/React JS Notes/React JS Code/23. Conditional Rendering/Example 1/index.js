import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

ReactDOM.render(<App consumer={true} />, document.getElementById("root"));
// ReactDOM.render(<App consumer={false} />, document.getElementById("root"));
