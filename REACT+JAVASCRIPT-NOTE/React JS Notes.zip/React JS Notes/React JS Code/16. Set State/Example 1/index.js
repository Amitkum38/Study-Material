import React from "react";
import ReactDOM from "react-dom";
import Student from "./Student";

ReactDOM.render(<Student roll="101" />, document.getElementById("root"));
