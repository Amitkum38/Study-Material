import React from "react";
import Student from "./Student";
const App = () => {
  return (
    <div>
      <Student name="Rahul" />
      <Student name="Sonam" />
      <Student name="Sumit" />
    </div>
  );
};

export default App;
