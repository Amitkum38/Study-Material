import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

// Rendering Component
ReactDOM.render(<App name="I_am_App_Prop" />, document.getElementById("root"));
