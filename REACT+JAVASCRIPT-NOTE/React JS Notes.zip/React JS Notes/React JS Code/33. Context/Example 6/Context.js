import React from "react";
const MyContext = React.createContext("Raat bahot ho gayi hai");
export const Provider = MyContext.Provider;
export const Consumer = MyContext.Consumer;
