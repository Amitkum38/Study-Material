import React from "react";
import ReactDOM from "react-dom";
import Student from "./Student";

// Rendering Component
ReactDOM.render(
  <Student name="Rahul" roll="101" />,
  document.getElementById("root")
);
