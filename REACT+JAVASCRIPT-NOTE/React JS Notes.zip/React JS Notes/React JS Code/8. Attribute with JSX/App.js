import React from "react";
// Importing CSS File
import "./App.css";

// Attribute with JSX
const el = <h1 className="bg">Hello</h1>;

// Attribute with JSX (Below Code is only for describing concept, It won't work)
// const el = <h1 className={bg}>Hello</h1>;

export default el;
