import React from "react";
import ReactDOM from "react-dom";
import Student from "./Student";

// Rending Component
ReactDOM.render(<Student>I am child</Student>, document.getElementById("root"));
